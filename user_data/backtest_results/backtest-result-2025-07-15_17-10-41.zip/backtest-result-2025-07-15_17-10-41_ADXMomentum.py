# --- Do not remove these libs ---
from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


# --------------------------------


class ADXMomentum(IStrategy):
    """

    author@: Gert Wohlgemuth

    converted from:

        https://github.com/sthewissen/Mynt/blob/master/src/Mynt.Core/Strategies/AdxMomentum.cs

    """

    INTERFACE_VERSION: int = 3

    # Optimal parameters found by hyperopt
    
    # ROI table:
    minimal_roi = {
        "0": 0.143,
        "30": 0.093,
        "51": 0.032,
        "115": 0
    }

    # Stoploss:
    stoploss = -0.101

    # Optimal timeframe for the strategy.
    # Note: This was optimized for '5m' timeframe.
    timeframe = '5m'

    # Number of candles the strategy requires before producing valid signals
    startup_candle_count: int = 48

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=25)
        dataframe['plus_di'] = ta.PLUS_DI(dataframe, timeperiod=48)
        dataframe['minus_di'] = ta.MINUS_DI(dataframe, timeperiod=48)
        dataframe['sar'] = ta.SAR(dataframe)
        dataframe['mom'] = ta.MOM(dataframe, timeperiod=32)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                    (dataframe['adx'] > 25) &
                    (dataframe['mom'] > 0) &
                    (dataframe['plus_di'] > 50) &
                    (dataframe['plus_di'] > dataframe['minus_di'])

            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                    (dataframe['adx'] > 43) &
                    (dataframe['mom'] < 0) &
                    (dataframe['minus_di'] > 26) &
                    (dataframe['plus_di'] < dataframe['minus_di'])

            ),
            'exit_long'] = 1
        return dataframe
